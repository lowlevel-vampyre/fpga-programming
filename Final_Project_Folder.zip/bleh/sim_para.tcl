lappend auto_path "C:/lscc/diamond/3.13/data/script"
package require simulation_generation
set ::bali::simulation::Para(DEVICEFAMILYNAME) {MachXO3D}
set ::bali::simulation::Para(PROJECT) {bleh}
set ::bali::simulation::Para(PROJECTPATH) {C:/Users/vboxuser/Desktop/Final Project Folder}
set ::bali::simulation::Para(FILELIST) {"C:/Users/vboxuser/Desktop/Final Project Folder/spram.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/bus_master.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/adc_controller.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/buck_controller.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/led_controller.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/rs232.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/PLL_CLK.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/clk_gen.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/Final_TOP.vhd" "C:/Users/vboxuser/Desktop/Final Project Folder/final_tb.vhd" }
set ::bali::simulation::Para(GLBINCLIST) {}
set ::bali::simulation::Para(INCLIST) {"none" "none" "none" "none" "none" "none" "none" "none" "none" "none"}
set ::bali::simulation::Para(WORKLIBLIST) {"work" "work" "work" "work" "work" "work" "work" "work" "work" "work" }
set ::bali::simulation::Para(COMPLIST) {"VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" }
set ::bali::simulation::Para(LANGSTDLIST) {"" "" "" "" "" "" "" "" "" "" }
set ::bali::simulation::Para(SIMLIBLIST) {pmi_work ovi_machxo3d}
set ::bali::simulation::Para(MACROLIST) {}
set ::bali::simulation::Para(SIMULATIONTOPMODULE) {final_tb}
set ::bali::simulation::Para(SIMULATIONINSTANCE) {}
set ::bali::simulation::Para(LANGUAGE) {VHDL}
set ::bali::simulation::Para(SDFPATH)  {}
set ::bali::simulation::Para(INSTALLATIONPATH) {C:/lscc/diamond/3.13}
set ::bali::simulation::Para(ADDTOPLEVELSIGNALSTOWAVEFORM)  {1}
set ::bali::simulation::Para(RUNSIMULATION)  {1}
set ::bali::simulation::Para(HDLPARAMETERS) {}
set ::bali::simulation::Para(POJO2LIBREFRESH)    {}
set ::bali::simulation::Para(POJO2MODELSIMLIB)   {}
::bali::simulation::ModelSim_Run
